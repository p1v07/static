package main

import (
	"aedv3/pkg/cli"
	"aedv3/pkg/plugin"
	_ "aedv3/pkg/tomcat"
	"aedv3/pkg/utils"

	"github.com/sirupsen/logrus"
)

func main() {
	cli.Parse()
	logrus.Debugf("len: %d", len(plugin.Infos))
	for name, info := range plugin.Infos {
		logrus.Infof("%s info gathering", name)
		utils.Wg.Add(1)
		go info.Run()
	}
	utils.Wg.Wait()
}
