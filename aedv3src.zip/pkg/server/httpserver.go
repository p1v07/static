package server

import (
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/sirupsen/logrus"
)

func HttpServer(address string) {
	http.HandleFunc("/api/upload", func(w http.ResponseWriter, r *http.Request) {
		r.ParseMultipartForm(32 << 20)
		r.FormFile("uploadfile")
		file, handler, err := r.FormFile("uploadfile")
		if err != nil {
			fmt.Println(err)
			return
		}
		defer file.Close()
		fmt.Fprintf(w, "%v", handler.Header)
		savename := r.Form.Get("savename")
		if strings.Contains(savename, "../") {
			logrus.Warn("err filename")
			return
		}
		appName := r.Form.Get("appname")
		filename := "./infoGather/" + appName + "/" + savename
		logrus.Infof("saved %s", filename)
		dirname := filepath.Dir(filename)
		if _, err := os.Stat(dirname); os.IsNotExist(err) {
			mderr := os.MkdirAll(dirname, 0755)
			if mderr != nil {
				logrus.Warn(mderr)
			}
		}
		f, err := os.OpenFile(filename, os.O_WRONLY|os.O_CREATE, 0666)
		if err != nil {
			logrus.Warn(err)
			return
		}
		defer f.Close()
		io.Copy(f, file)

	})
	logrus.Infof("http server listen on %s", address)
	err := http.ListenAndServe(address, nil)
	if err != nil {
		logrus.Fatal("ListenAndServe: ", err)
	}
}
