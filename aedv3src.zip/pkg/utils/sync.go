package utils

import "sync"

var Wg sync.WaitGroup
