package utils

import (
	"aedv3/pkg/cli"
	"fmt"
	"os"

	"github.com/sirupsen/logrus"
	"github.com/tidwall/gjson"
)

func uploadResultToServer(appName string, fileName string) {
	if *cli.ConnectAddr != "" {
		serverUrl := fmt.Sprintf("%s%s", *cli.ConnectAddr, "/api/upload")
		postFile(fileName, appName, serverUrl)
	} else {
		logrus.Info("-ca to specify connect address to upload result files")
	}

}

func saveResult(name string, resp string) {
	result := gjson.Get(resp, `body.results.#(type=="watch").value`)
	saveFileName := fmt.Sprintf("%s/%s.txt", cli.SaveDirName, name)
	fmt.Printf("[!] %s success:\n%s\n", name, result.String())
	writeFile(saveFileName, result.String())
	uploadResultToServer(*cli.AppName, saveFileName)
}

func writeFile(saveFileName string, content string) {
	if _, err := os.Stat(cli.SaveDirName); os.IsNotExist(err) {
		err := os.MkdirAll(cli.SaveDirName, 0755)
		if err != nil {
			logrus.Warnf("mkdir %s err", cli.SaveDirName)
			return
		}
		logrus.Debugf("mkdir %s success", cli.SaveDirName)
	}
	f, er := os.Create(saveFileName)
	if er != nil {
		logrus.Error(er)
	} else {
		f.WriteString(content)
	}
	logrus.Infof("saving result to %s", saveFileName)
}

func saveSpringCloudGatewayPropertiesResult(name string, resp string) {
	// saveResult(name, resp)
	saveAllFileName := fmt.Sprintf("%s/%sAll.txt", cli.SaveDirName, name)
	result := gjson.Get(resp, `body.results.#(type=="watch").value|@pretty:{"sortKeys":true}`)
	writeFile(saveAllFileName, result.String())
	uploadResultToServer(*cli.AppName, saveAllFileName)

	saveFileName := fmt.Sprintf("%s/%s.txt", cli.SaveDirName, name)
	content := gjson.Get(result.String(), `#(name%"*center").source|@pretty:{"sortKeys":true}`).String()
	fmt.Printf("[!] %s success:\n%s\n", name, content)
	writeFile(saveFileName, content)
	uploadResultToServer(*cli.AppName, saveFileName)
}
