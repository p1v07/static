package utils

import (
	"aedv3/pkg/cli"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"os"
	"time"

	"github.com/sirupsen/logrus"
	"github.com/tidwall/gjson"
)

func Send() {
	fmt.Println("send func")
}

func Hi() {
	fmt.Println("Hi func")
}

func ExecOnce(data map[string]string, name string, print bool) string {
	jsonValue, _ := json.Marshal(data)
	req, _ := http.NewRequest("POST", cli.ApiUrl, bytes.NewBuffer(jsonValue))
	req.Header.Set("Content-Type", "application/json")
	req.Close = true
	client := &http.Client{
		Timeout: 60 * time.Second,
	}
	resp, err := client.Do(req)
	if err != nil {
		logrus.Error(err)
		return ""
	}
	body, _ := ioutil.ReadAll(resp.Body)
	result := gjson.Get(string(body), `@pretty:{"sortKeys":true}`)
	if print {
		logrus.Infof("%s:\n%s", name, result.String())
	}
	return string(body)
}

func postFile(filename string, appName string, targetUrl string) error {
	bodyBuf := &bytes.Buffer{}
	bodyWriter := multipart.NewWriter(bodyBuf)

	fileWriter, err := bodyWriter.CreateFormFile("uploadfile", filename)
	if err != nil {
		logrus.Warn("error writing to buffer")
		return err
	}

	fh, err := os.Open(filename)
	if err != nil {
		logrus.Warn("error opening file")
		return err
	}
	defer fh.Close()

	//iocopy
	_, err = io.Copy(fileWriter, fh)
	if err != nil {
		return err
	}

	bodyWriter.WriteField("appname", appName)
	bodyWriter.WriteField("savename", filename)

	contentType := bodyWriter.FormDataContentType()
	bodyWriter.Close()

	resp, err := http.Post(targetUrl, contentType, bodyBuf)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	resp_body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return err
	}
	logrus.Debug(resp.Status)
	logrus.Debug(string(resp_body))
	return nil
}
