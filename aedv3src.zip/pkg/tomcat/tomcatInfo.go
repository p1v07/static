package tomcat

import (
	"aedv3/pkg/plugin"
	"aedv3/pkg/utils"
	_ "embed"
	"fmt"

	"github.com/sirupsen/logrus"
	"github.com/tidwall/gjson"
)

type TomcatInfo struct{}

func (info TomcatInfo) Desc() string {
	return "tomcat filter and other infos"
}

//go:embed tomcat.ognl
var tomcatOgnl string

func (info TomcatInfo) Run() bool {

	logrus.Debug("tomcat info plugin running...")
	cmd := fmt.Sprintf(`vmtool --action getInstances --className org.apache.catalina.mapper.Mapper --express '%s'`, tomcatOgnl)
	data := map[string]string{
		"action":  "exec",
		"command": cmd,
	}
	resp := utils.ExecOnce(data, "tomcat", false)
	jobStatus := gjson.Get(resp, `body.state`).String()
	logrus.Debugf("jobstatus: [%s]", jobStatus)
	statusCode := gjson.Get(resp, `body.results.#(type=="status").statusCode`).Int()
	logrus.Debugf("statuscode: [%d]", statusCode)
	value := gjson.Get(resp, `body.results.#(type=="vmtool").value`).String()
	if value != "" {
		logrus.Infof("[=] job(%s) successed :\n%s", "tomcat", value)
		// fmt.Println(gjson.Get(resp, `body.results.#(type=="watch").value`).String())

	} else if statusCode == -1 {
		logrus.Debugf("pulljoberror(tomcat) maybe need retry %s", resp)
	}
	utils.Wg.Done()
	return true
}

func init() {
	info := TomcatInfo{}
	logrus.Debug("init tomcat info plugin")
	plugin.RegisterInfo("tomcat", info)
}
