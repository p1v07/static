package cli

import (
	"flag"
	"fmt"
	"io/ioutil"
	"os"
	"path"
	"path/filepath"
	"runtime"
	"strings"

	nested "github.com/antonfisher/nested-logrus-formatter"
	"github.com/sirupsen/logrus"
)

var pid *string
var ip *string
var port *string
var stop *bool
var randomMode *bool
var javapath *string
var asyncMode *bool
var sinkMode *bool
var serverMode *bool
var serverPort *string
var tomcatPort *string
var execCmd *string
var AppName *string
var ConnectAddr *string
var ApiUrl string

var currentTime string
var SaveDirName string

var usage = `
example:
for p in $(ps -ef |grep java |grep /opt/oss/envs/Product-NetEco |awk '{print $2}');do echo "=========================="; %s -stop ;%s -pid $p -j /opt/.x/jdk1.8.0_332/bin/java -debug ;done 2>&1 |tee getroutesv2.log

-port 8563 -ca http://7.186.55.108:38888 -app fdngateway
`

var cwd, _ = filepath.Abs(filepath.Dir(os.Args[0]))

func Parse() {

	logrus.SetReportCaller(true)

	logrus.SetFormatter(&nested.Formatter{
		CallerFirst: true,
		CustomCallerFormatter: func(frame *runtime.Frame) string {
			fileName := path.Base(frame.File)
			return fmt.Sprintf(" %s:%d", fileName, frame.Line)
		},
	})

	ip = flag.String("ip", "127.0.0.1", "arthas server ip")
	port = flag.String("port", "38563", "arthas server port")
	pid = flag.String("pid", "", "jvm pid to attach, split by comma")
	AppName = flag.String("app", "", "标识当前jvm的名字，用于保存结果文件夹")
	stop = flag.Bool("stop", false, "stop arthas")
	asyncMode = flag.Bool("async", true, "async mode")
	javapath = flag.String("j", "", "jdk java full path")
	randomMode = flag.Bool("random", false, "random port to attach")
	sinkMode = flag.Bool("sinks", false, "sink watching mode")
	debug := flag.Bool("debug", false, "debug mode to output more info")
	// overide := flag.Bool("o", false, "overide result")
	tomcatPort = flag.String("tp", "", "tomcat port condition, like ==8080, != 9080")
	execCmd = flag.String("ec", "", "exec cmd via arthas http api")

	serverPort = flag.String("sp", ":38888", "server listen port")
	serverMode = flag.Bool("sm", false, "server listen mode")
	ConnectAddr = flag.String("ca", "http://7.186.55.108:38888", "connect addresss, like http://127.0.0.1:38888")

	flag.Usage = func() {
		fmt.Fprint(flag.CommandLine.Output(), "get info based on arthas\n")
		flag.PrintDefaults()
		fmt.Fprintf(flag.CommandLine.Output(), usage, os.Args[0], os.Args[0])
	}
	flag.Parse()
	autoDetectAppName()
	if *debug {
		logrus.SetLevel(logrus.DebugLevel)
	}
	if *javapath == "" {
		files, _ := ioutil.ReadDir(fmt.Sprintf("%s/../", cwd))
		for _, f := range files {
			if f.IsDir() && strings.HasPrefix(f.Name(), "jdk") {
				*javapath = fmt.Sprintf("%s/../%s/bin/java", cwd, f.Name())
				logrus.Debugf("auto detected jdk java path: %s", *javapath)
			}
		}
	}
	ApiUrl = fmt.Sprintf("http://%s:%s/api", *ip, *port)

}

func autoDetectAppName() {
	if *AppName != "" {
		return
	}
	if os.Getenv("POD_NAME") != "" {
		*AppName = os.Getenv("POD_NAME")
		logrus.Infof("auto detected AppName with POD_NAME env: %s", *AppName)
	}
}
