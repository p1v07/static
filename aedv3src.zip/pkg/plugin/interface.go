package plugin

import (
	"fmt"
	"os"
	"text/tabwriter"
)

type InfoInterface interface {
	Desc() string
	Run() bool
}

var Infos map[string]InfoInterface

type Callback func(name string, resp string)

func init() {
	Infos = make(map[string]InfoInterface)
}

func ListAllInfo() {
	writer := tabwriter.NewWriter(os.Stdout, 1, 1, 1, ' ', 0)

	for name, plugin := range Infos {
		str := fmt.Sprintf("%s\t %s", name, plugin.Desc())
		fmt.Fprintln(writer, str)
	}

	writer.Flush()
}

func RunSingleInfo(name string) {
	Infos[name].Run()
}

func RegisterInfo(name string, info InfoInterface) {
	Infos[name] = info
}
